local module = {}

-- Your city for the weather forecast widget
module.city_id = 3154084

-- Load color schemes from xresources
module.use_xresources = true

-- Set resource for temperature widget
-- module.tempfile = '/sys/devices/virtual/thermal/thermal_zone1/temp'

return module