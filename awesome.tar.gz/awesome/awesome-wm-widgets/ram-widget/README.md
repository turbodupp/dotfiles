# Ram widget

This widget shows the RAM usage. When clicked another widget appears with more detailed information:

![screenshot](./out.gif)

## Installation

Please refer to the [installation](https://github.com/streetturtle/awesome-wm-widgets#installation) section of the repo.